# BorderCollies
Simple image "src"-swaping Chrome app.

---------------
Background.js defines the action performed when the button is clicked.

content_script.js is the actual code that runs each time the button is pressed.
